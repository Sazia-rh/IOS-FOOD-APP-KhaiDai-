//
//  ViewController.swift
//  upload2
//
//  Created by Asnuva Tanvin on 4/11/21.
//

import UIKit
import Firebase
import FirebaseStorage

class Add_RecipeViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func addimage(_ sender: UIButton) {
        let ac = UIAlertController(title: "Select Image", message: "Select image from?" , preferredStyle: .actionSheet)
        //let cameraBtn = UIAlertAction(title: "Camera", style: .default) {[weak self] (_) in
            //self?.showImagePicker(selectedSource: .camera)
        //}
        let libraryBtn = UIAlertAction(title: "Library", style: .default) {[weak self] (_) in
            self?.showImagePicker(selectedSource: .photoLibrary)
        }
        let cancelBtn = UIAlertAction(title: "Cancel", style: .cancel , handler: nil)
        //ac.addAction(cameraBtn)
        ac.addAction(libraryBtn)
        ac.addAction(cancelBtn)
        self.present(ac , animated: true, completion: nil)
    }
    
    @IBOutlet weak var imgView: UIImageView!
    func showImagePicker(selectedSource: UIImagePickerController.SourceType){
        guard UIImagePickerController.isSourceTypeAvailable(selectedSource) else{
            print("Selected source not available ")
            return
        }
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = selectedSource
        imagePickerController.allowsEditing = true
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectImage = info[.editedImage] as? UIImage{
            imgView.image = selectImage
            
            let storageRef = Storage.storage().reference().child("myImage.png")
            if let uploadData = self.imgView.image!.pngData() {
                storageRef.putData(uploadData, metadata: nil) { (metadata, error) in
                    if error != nil {
                        print("error")
                        //completion(nil)
                    } else {
                        //completion((metadata?.downloadURL()?.absoluteString)!);)
                        // your uploaded photo url.
                    }
               }
        }
        else{
            print("image not found")
        }
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
        
        
    }
}
