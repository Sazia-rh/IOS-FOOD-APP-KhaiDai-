//
//  Constants.swift
//  KhaiDai
//
//  Created by Asnuva Tanvin on 30/10/21.
//

import Foundation

struct Constants {
    
    struct Storyboard{
        
        static let homeViewController = "HomeVC"
    }
}
