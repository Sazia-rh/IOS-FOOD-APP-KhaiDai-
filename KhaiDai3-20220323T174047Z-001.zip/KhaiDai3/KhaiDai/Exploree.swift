//
//  Exploree.swift
//  KhaiDai
//
//  Created by Asnuva Tanvin on 7/11/21.
//

import Foundation
import UIKit

class Exploree{
    var name: String?
    var imgURL: String?
    var recipe: String?
    
    init(name: String, imgURL: String, recipe: String){
        
        self.name = name
        self.imgURL = imgURL
        self.recipe = recipe
    }
}
