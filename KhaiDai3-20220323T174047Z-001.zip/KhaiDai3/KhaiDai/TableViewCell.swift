//
//  TableViewCell.swift
//  KhaiDai
//
//  Created by Asnuva Tanvin on 7/11/21.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var RecipeImage: UIImageView!
    
    @IBOutlet weak var LabelName: UILabel!
    
    @IBOutlet weak var RecipeText: UITextView!
    
    var explore: Exploree?{
        didSet{
            LabelName.text = explore?.name
            RecipeText.text = explore?.recipe
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
