//
//  RetriveViewController.swift
//  KhaiDai
//
//  Created by Asnuva Tanvin on 9/11/21.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseDatabase

class RetriveViewController: UIViewController {
    
    @IBOutlet weak var TableView: UITableView!
    
    var ref = DatabaseReference.init()
    var arrayData = [Exploree]()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.ref = Database.database().reference()
        self.getAllFIRData()

        // Do any additional setup after loading the view.
    }
    
    func getAllFIRData(){
        self.ref.child("post").queryOrderedByKey().observe(.value){(snapshot) in
            self.arrayData.removeAll()
            if let snapp = snapshot.children.allObjects as? [DataSnapshot]{
                for childd in snapp{
                    if let Dict = childd.value as? [String: AnyObject]{
                    if let snap = childd.children.allObjects as? [DataSnapshot]{
                        for child in snap{
                            if let mainDict = child.value as? [String: AnyObject]{
                                let name = mainDict["name"] as? String
                                let recipe = mainDict["recipe"] as? String
                                let imgURL = mainDict["img"] as? String ?? ""
                                self.arrayData.append(Exploree(name: name!,imgURL: imgURL,recipe: recipe!))
                                self.TableView.reloadData()
                            }
                        }
                    }
                }
            }
         }
      }
   }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension RetriveViewController:UITableViewDelegate, UITableViewDataSource{
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell",for: indexPath) as! TableViewCell
        cell.explore = arrayData[indexPath.row]
        return cell
    }
    
}

