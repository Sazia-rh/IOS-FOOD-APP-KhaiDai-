//
//  ViewController.swift
//  upload2
//
//  Created by Asnuva Tanvin on 4/11/21.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseDatabase

class Add_RecipeViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    var ref = DatabaseReference.init()
    let imagePicker = UIImagePickerController()
    let userId = (Auth.auth().currentUser?.uid)!
    var currentImage: UIImage!
    //var arrayData = [Exploree]()
    
    
    //@IBOutlet weak var TableView: UITableView!
    
    //@IBOutlet weak var TableView: UITableView!
    
    
    @IBOutlet weak var txtText: UITextField!
    
    @IBOutlet weak var myImageView: UIImageView!
    
    @IBOutlet weak var recipeText: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.ref = Database.database().reference()
        //self.getAllFIRData()
    }
    
    @IBAction func postTapped(_ sender: UIButton) {
       self.saveFIRData()
    }
    func saveFIRData(){
        self.uploadImage(self.myImageView.image!){
            
            url in
            self.saveImg(name: self.txtText.text!, profileURL: url!){ success in
                if success != nil {
                    print("yes")
                }
            }
        }
        //self.getAllFIRData()
        
        
    }
    
  
    
    @IBAction func addimage(_ sender: UIButton) {
        let ac = UIAlertController(title: "Select Image", message: "Select image from?" , preferredStyle: .actionSheet)
        
        let libraryBtn = UIAlertAction(title: "Library", style: .default) {[weak self] (_) in
            self?.showImagePicker(selectedSource: .photoLibrary)
        }
        let cancelBtn = UIAlertAction(title: "Cancel", style: .cancel , handler: nil)
        //ac.addAction(cameraBtn)
        ac.addAction(libraryBtn)
        ac.addAction(cancelBtn)
        self.present(ac , animated: true, completion: nil)
    }
    
    @IBOutlet weak var imgView: UIImageView!
    func showImagePicker(selectedSource: UIImagePickerController.SourceType){
        guard UIImagePickerController.isSourceTypeAvailable(selectedSource) else{
            print("Selected source not available ")
            return
        }
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.sourceType = selectedSource
        imagePickerController.allowsEditing = true
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectImage = info[.editedImage] as? UIImage{
        myImageView.image = selectImage
            
            
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
        
   }
    
//    func getAllFIRData(){
//        self.ref.child("post").queryOrderedByKey().observe(.value){(snapshot) in
//            self.arrayData.removeAll()
//            if let snapp = snapshot.children.allObjects as? [DataSnapshot]{
//                for childd in snapp{
//                    if let Dict = childd.value as? [String: AnyObject]{
//                    if let snap = childd.children.allObjects as? [DataSnapshot]{
//                        for child in snap{
//                            if let mainDict = child.value as? [String: AnyObject]{
//                                let name = mainDict["name"] as? String
//                                let recipe = mainDict["recipe"] as? String
//                                let imgURL = mainDict["img"] as? String ?? ""
//                                self.arrayData.append(Exploree(name: name!,imgURL: imgURL,recipe: recipe!))
//                                self.TableView.reloadData()
//                            }
//                        }
//                    }
//                }
//            }
//         }
//      }
//   }
}


extension Add_RecipeViewController{
    
    func uploadImage(_ image:UIImage,completion: @escaping ((_ url:URL?) -> ())){
       // var a = 0
        let text = txtText.text!
        let storageRef = Storage.storage().reference().child("image_" + userId + "_" + text + "_.jpg")
        
        let imgData = myImageView.image?.pngData()
        let metaData = StorageMetadata()
        metaData.contentType = "image/png"
        storageRef.putData( imgData!, metadata: metaData) { (metaData,error) in
            if error == nil
            {
                print("success")
                storageRef.downloadURL(completion: {
                    (url,error) in completion(url!)
                })
            }
            else{
                print("error")
                completion(nil)
            }
        }
        
    }
    func saveImg ( name: String , profileURL: URL , completion: @escaping ((_ url:URL?) -> () )){
        let dict = ["name": txtText.text!,"img": profileURL.absoluteString , "recipe": recipeText.text!] as [String: Any]
        //let ddict = ["name": txtText.text!, "description":dict] as [String : Any] as [String : Any]
        let text = txtText.text!
        
        //self.ref.child("post").setValue(userId)
        self.ref.child("post").child(userId).child(text).setValue(dict)
        
        
    }
    
}

//extension Add_RecipeViewController:UITableViewDelegate, UITableViewDataSource{
//
//
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return arrayData.count
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//       let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell",for: indexPath) as! TableViewCell
//        cell.explore = arrayData[indexPath.row]
//        return cell
//    }
//
//}
