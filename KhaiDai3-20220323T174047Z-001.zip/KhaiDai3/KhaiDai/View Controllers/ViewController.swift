//
//  ViewController.swift
//  KhaiDai
//
//  Created by Asnuva Tanvin on 29/10/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var SignUpButton: UIButton!
    
    @IBOutlet weak var LogInButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpElements()
        // Do any additional setup after loading the view.
    }
    
    func setUpElements(){
        
        Utilities.styleFilledButton(SignUpButton)
        Utilities.styleFilledButton(LogInButton)
    }


}

