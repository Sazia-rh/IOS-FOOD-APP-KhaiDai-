//
//  ViewController.swift
//  Json
//
//  Created by Asnuva Tanvin on 7/11/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

